﻿using System;
using System.Collections.Generic;

namespace ShoppingCartApp
{
    class Program
    {
        static void Main(string[] args)
        {
            ShoppingCart cart = new ShoppingCart();
            bool running = true;

            while (running)
            {
                Console.WriteLine("Welcome to the Shopping Cart!");
                Console.WriteLine("1. Add Product");
                Console.WriteLine("2. Remove Product");
                Console.WriteLine("3. View Cart");
                Console.WriteLine("4. Checkout");
                Console.WriteLine("5. Exit");
                Console.Write("Select an option: ");
                var choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        cart.AddProduct();
                        break;
                    case "2":
                        cart.RemoveProduct();
                        break;
                    case "3":
                        cart.ViewCart();
                        break;
                    case "4":
                        cart.Checkout();
                        break;
                    case "5":
                        running = false;
                        break;
                    default:
                        Console.WriteLine("Invalid option. Please try again.");
                        break;
                }
            }
        }
    }

    public class ShoppingCart
    {
        private List<Product> _cart;
        private const double SalesTaxRate = 0.07;

        public ShoppingCart()
        {
            _cart = new List<Product>();
        }

        public void AddProduct()
        {
            Console.Write("Enter product name: ");
            string name = Console.ReadLine();
            Console.Write("Enter product price: ");
            double price = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter quantity: ");
            int quantity = Convert.ToInt32(Console.ReadLine());

            Product product = new Product(name, price, quantity);
            _cart.Add(product);
            Console.WriteLine($"Added {quantity} x {name} to the cart.");
        }

        public void RemoveProduct()
        {
            Console.Write("Enter the name of the product to remove: ");
            string name = Console.ReadLine();
            var product = _cart.Find(p => p.Name.Equals(name, StringComparison.OrdinalIgnoreCase));

            if (product != null)
            {
                _cart.Remove(product);
                Console.WriteLine($"Removed {name} from the cart.");
            }
            else
            {
                Console.WriteLine("Product not found in the cart.");
            }
        }

        public void ViewCart()
        {
            Console.WriteLine("\nShopping Cart:");
            if (_cart.Count == 0)
            {
                Console.WriteLine("The cart is empty.");
                return;
            }

            foreach (var product in _cart)
            {
                Console.WriteLine($"{product.Quantity} x {product.Name} @ ${product.Price:F2} each");
            }

            Console.WriteLine($"Total before tax: ${CalculateSubtotal():F2}");
            Console.WriteLine($"Total after tax: ${CalculateTotal():F2}\n");
        }

        public void Checkout()
        {
            Console.WriteLine("Checking out...");
            Console.WriteLine($"Total amount due: ${CalculateTotal():F2}");
            _cart.Clear();
            Console.WriteLine("Thank you for your purchase!\n");
        }

        private double CalculateSubtotal()
        {
            double subtotal = 0;
            foreach (var product in _cart)
            {
                subtotal += product.Price * product.Quantity;
            }
            return subtotal;
        }

        private double CalculateTotal()
        {
            return CalculateSubtotal() * (1 + SalesTaxRate);
        }
    }

    public class Product
    {
        public string Name { get; }
        public double Price { get; }
        public int Quantity { get; set; }

        public Product(string name, double price, int quantity)
        {
            Name = name;
            Price = price;
            Quantity = quantity;
        }
    }
}
